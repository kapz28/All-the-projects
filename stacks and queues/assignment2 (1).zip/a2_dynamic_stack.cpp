#include <iostream>
#include "a2_dynamic_stack.hpp"

typedef DynamicStack::StackItem StackItem;  // for simplicity
const StackItem DynamicStack::EMPTY_STACK = -999;

DynamicStack::DynamicStack()
{
}

DynamicStack::DynamicStack(unsigned int size_)
{
}

DynamicStack::~DynamicStack()
{
}

bool DynamicStack::empty() const
{
}

int DynamicStack::size() const
{
}

void DynamicStack::push(StackItem value)
{
}

StackItem DynamicStack::pop()
{
}

StackItem DynamicStack::peek() const
{
}

void DynamicStack::print() const
{
}

