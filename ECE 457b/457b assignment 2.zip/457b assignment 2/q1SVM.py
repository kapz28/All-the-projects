# ECE 457b
# Kapilan Satkunanathan
# 20694418
# Assignment 2 Question 1

import numpy as np

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, MinMaxScaler
from sklearn.svm import SVC
from sklearn.metrics import confusion_matrix, classification_report, ConfusionMatrixDisplay


from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam

import csv
import matplotlib.pyplot as plt

x = []
y_ = []
with open('diabetes.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    line_count = 0
    for row in csv_reader:
        if line_count == 0:
            print(f'Column names are {", ".join(row)}')
            line_count += 1
        else:
            x.append(row[:-1])
            y_.append(row[-1])
            line_count += 1
    print(f'Processed {line_count} lines.')


x = np.array(x).astype(np.float)
y_ = np.array(y_).astype(np.float)
# iris = load_iris()
# x = iris.data
# y_ = iris.target

print("Size of features: {}".format(x.shape))
print("Size of labels: {}".format(y_.shape))

print("Sample data: {}".format(x[:3]))
print("Sample labels: {}".format(y_))

class_names = ['No Diabetes', 'Has Diabetes']



# Normalize the data
X_norm = (x - x.min(axis=0)) / (x.max(axis=0) - x.min(axis=0))

# One-hot encode the labels
encoder = OneHotEncoder(sparse=False)

# Split the data into training and testing
train_x, test_x, train_y, test_y = train_test_split(X_norm, y_, test_size=0.20)

train_y_enc = encoder.fit_transform(train_y.reshape(-1,1))
test_y_enc = encoder.fit_transform(test_y.reshape(-1,1))

print("Sample train data: {}".format(train_x[:3]))
print("Sample train labels: {}".format(train_y_enc[:3]))

for C in [0.1, 1, 10]:
    svm_ = SVC(kernel='linear', C=C)
    svm_.fit(train_x, train_y)

    y_svm = svm_.predict(test_x)
    acc_svm = sum([1 for i in range(0,len(test_y)) if test_y[i] == y_svm[i] ])/len(test_y)

    print("SVM Accuracy: {}%".format(acc_svm*100))

    cm_svm = confusion_matrix(test_y, y_svm)
    print(cm_svm)
    print(classification_report(test_y, y_svm, target_names=class_names))

    disp2 = ConfusionMatrixDisplay(confusion_matrix=cm_svm,display_labels=class_names)
    disp2.plot()
    plt.xlabel('C='+str(C))
    plt.ylabel('Kernel type = Linear')
    plt.show()

for C in [0.1, 1, 10]:
    svm_ = SVC(kernel='poly', C=C)
    svm_.fit(train_x, train_y)

    y_svm = svm_.predict(test_x)
    acc_svm = sum([1 for i in range(0,len(test_y)) if test_y[i] == y_svm[i] ])/len(test_y)

    print("SVM Accuracy: {}%".format(acc_svm*100))

    cm_svm = confusion_matrix(test_y, y_svm)
    print(cm_svm)
    print(classification_report(test_y, y_svm, target_names=class_names))

    disp2 = ConfusionMatrixDisplay(confusion_matrix=cm_svm,display_labels=class_names)
    disp2.plot()
    plt.xlabel('C='+str(C))
    plt.ylabel('Kernel type = Polynomial')
    plt.show()