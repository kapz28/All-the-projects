# ECE 457b
# Kapilan Satkunanathan
# 20694418
# Assignment 2 Question 2

from __future__ import division
from __future__ import print_function
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Conv2D, MaxPool2D, Flatten, Dropout
from tensorflow.keras.datasets import mnist
from tensorflow.keras.datasets import cifar10
from tensorflow.keras.utils import to_categorical
from sklearn.model_selection import train_test_split


(train_images, train_labels), (test_images, test_labels) = cifar10.load_data()
# Split the data into training and testing
train_x, test_x, train_y, test_y = train_test_split(train_images, train_labels, test_size=0.20)
train_images = train_x
train_labels = train_y
test_images = test_x
test_labels = test_y


train_labels = to_categorical(train_labels, num_classes=10)
test_labels = to_categorical(test_labels, num_classes=10)
print('train images shape:', train_images.shape)
print('train labels shape:', train_labels.shape)
print('test images shape:', test_images.shape)
print('test labels shape:', test_labels.shape)


train_images = train_images.astype(np.float32)
mean = np.mean(train_images)
std = np.std(train_images)
train_images = (train_images - mean) / std
test_images = (test_images - mean) / std

# MLP
mlp = Sequential()
mlp.add(Flatten(input_shape=(32, 32, 3)))
mlp.add(Dense(512,input_shape=(3072,), activation='sigmoid'))
mlp.add(Dense(10, activation='softmax'))

# Compile the model
mlp.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
h = mlp.fit(train_images.reshape(-1, 32, 32, 3),
        train_labels,
        batch_size=32,
        epochs=5,
        validation_data=(test_images.reshape(-1, 32, 32, 3), test_labels))

# Test the model after training
test_results = mlp.evaluate(test_images, test_labels, verbose=1)
print(f'MLP Test results - Loss: {test_results[0]} - Accuracy: {test_results[1]}%')

plt.xlabel('MLP')
plt.plot(h.history['accuracy'])
plt.plot(h.history['val_accuracy'], 'r')
plt.legend(['train acc', 'val acc'])
plt.show()
plt.clf()
plt.cla()

# weightsmlp = mlp.get_weights()[0]
# print(weightsmlp.shape)
# figone = plt.figure(facecolor='w', edgecolor='w', figsize=(8, 8))
# figone.subplots_adjust(wspace=0.05, hspace=0.05)
# for i in range(64):
#  spmlp = figone.add_subplot(8, 8, i+1)
#  spmlp.set_axis_off()
#  plt.xlabel('MLP')
#  plt.imshow(weightsmlp[:, :, 0, i])
#  plt.set_cmap('gray')
# plt.show()
# plt.clf()
# plt.cla()

# First CNN
cnnone = Sequential()
cnnone.add(Conv2D(filters=64, kernel_size=(3, 3), padding='same', activation='relu'
, input_shape=(32, 32, 3)))
cnnone.add(Flatten())
cnnone.add(Dense(512, activation='sigmoid'))
cnnone.add(Dense(512, activation='sigmoid'))
cnnone.add(Dense(10, activation='softmax'))

# Compile the model
cnnone.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
h = cnnone.fit(train_images.reshape(-1, 32, 32, 3),
        train_labels,
        batch_size=32,
        epochs=5,
        validation_data=(test_images.reshape(-1, 32, 32, 3), test_labels))

test_results = cnnone.evaluate(test_images, test_labels, verbose=1)
print(f'CNN One Test results - Loss: {test_results[0]} - Accuracy: {test_results[1]}%')

plt.xlabel('CNN One')
plt.plot(h.history['accuracy'])
plt.plot(h.history['val_accuracy'], 'r')
plt.legend(['train acc', 'val acc'])
plt.show()
plt.clf()
plt.cla()
# weightsone = cnnone.get_weights()[0]
# print(weightsone.shape)
# figone = plt.figure(facecolor='w', edgecolor='w', figsize=(8, 8))
# figone.subplots_adjust(wspace=0.05, hspace=0.05)
# for i in range(64):
#  spone = figone.add_subplot(8, 8, i+1)
#  spone.set_axis_off()
#  plt.xlabel('CNN one')
#  plt.imshow(weightsone[:, :, 0, i])
#  plt.set_cmap('gray')
# plt.show()
# plt.clf()
# plt.cla()


# Second CNN
cnntwo = Sequential()
cnntwo.add(Conv2D(filters=64, kernel_size=(3, 3), padding='same', activation='relu'
, input_shape=(32, 32, 3)))
cnntwo.add(MaxPool2D())
cnntwo.add(Conv2D(64, kernel_size=(3, 3), padding='same', activation='relu'))
cnntwo.add(MaxPool2D())
cnntwo.add(Flatten())
cnntwo.add(Dense(512, activation='sigmoid'))
cnntwo.add(Dropout(0.2))
cnntwo.add(Dense(512, activation='sigmoid'))
cnntwo.add(Dropout(0.2))
cnntwo.add(Dense(10, activation='softmax'))

# Compile the model
cnntwo.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
h = cnntwo.fit(train_images.reshape(-1, 32, 32, 3), 
        train_labels,
        batch_size=32,
        epochs=5,
        validation_data=(test_images.reshape(-1, 32, 32, 3), test_labels))

test_results = cnntwo.evaluate(test_images, test_labels, verbose=1)
print(f'CNN Two Test results - Loss: {test_results[0]} - Accuracy: {test_results[1]}%')

plt.xlabel('CNN Two')
plt.plot(h.history['accuracy'])
plt.plot(h.history['val_accuracy'], 'r')
plt.legend(['train acc', 'val acc'])
plt.show()
plt.clf()
plt.cla()
# weightstwo = cnntwo.get_weights()[0]
# print(weightstwo.shape)
# figtwo = plt.figure(facecolor='w', edgecolor='w', figsize=(8, 8))
# figtwo.subplots_adjust(wspace=0.05, hspace=0.05)
# for i in range(64):
#  sptwo = figtwo.add_subplot(8, 8, i+1)
#  sptwo.set_axis_off()
#  plt.xlabel('CNN two')
#  plt.imshow(weightstwo[:, :, 0, i])
#  plt.set_cmap('gray')
# plt.show()
# plt.clf()
# plt.cla()