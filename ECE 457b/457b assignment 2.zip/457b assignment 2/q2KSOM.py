# ECE 457b
# Kapilan Satkunanathan
# 20694418
# Assignment 2 Question 2

# Import packages
import numpy as np
import matplotlib.pyplot as plt
import time
from IPython import display
from minisom import MiniSom
import math

inputRGB = np.array([
[255,0,0],
[0,255,0],
[0,0,255],
[255,255,0],
[255,0,255],
[0,255,255],
[128,128,0],
[128,0,128],
[0,128,128],
[255,128,0],
[255,0,128],
[128,255,0],
[0,255,128],
[128,0,255],
[0,128,255],
[255,20,147],
[220,20,60],
[255,51,51],
[255,153,51],
[255,255,51],
[51,255,51],
[153,255,51],
[51,255,153],
[51,255,255]])

# Normalize the input (min-max normalize, but we already know the minimum and maximum)
normRGB = inputRGB/255

plt.imshow(np.reshape(normRGB,(normRGB.shape[0],1,3)))
print(normRGB.shape)

sigma_list = [10,40,70]
for sigma_0 in sigma_list:
    # Initialize the system
    space_size = 100 # 100 x 100 grid of neurons
    alpha_0 = 0.8
    # Nc = 100

    max_epochs = 600

    # Initialize random weights
    w = np.random.random((space_size,space_size,3))
    # diff = np.abs(np.sum(normRGB[0] - w, axis=2))
    plt.imshow(w)
    plt.xlabel('Initial generated neighbourhood')
    plt.ylabel('sigma='+str(sigma_0))
    plt.show()

    epoch = 1
    alpha = alpha_0

    sigma = sigma_0
    while epoch <= max_epochs:

        for x in normRGB:
            # calculate performance index
            diff = np.linalg.norm(x - w, axis =2)
            # find index of winning node
            ind = np.unravel_index(np.argmin(diff, axis=None), diff.shape)


            # Update weights for neighbourhood
            # for i in range(ind[0]-Nc, ind[0]+Nc+1):
            #     for j in range(ind[1]-Nc, ind[1]+Nc+1):
            for i in range(space_size):
                for j in range(space_size):
                    #if i >= 0 and j>=0 and i < space_size and j < space_size:
                    # print(i)
                    # print(j)
                    # make sure you don't exceed the size of the space
                    distance = math.sqrt(abs(i-ind[0])**2+abs(j-ind[1])**2)
                    Nij= math.exp(-((distance**2)/(2*(sigma**2))))
                    w[i][j] += alpha*Nij*(x-w[i][j])


        # decrease the learning rate by the given scheme
        alpha = alpha_0* math.exp(-epoch/(max_epochs+1))
        print("Learning rate decreased to {}".format(alpha))

        # decrease the sigma by the given scheme
        sigma = sigma_0* math.exp(-epoch/(max_epochs+1))
        print("Learning rate decreased to {}".format(alpha))

        plot_ind = [20, 40, 100, 600]
        if epoch in plot_ind:
            ind = plot_ind.index(epoch)
            #f = plt.figure(ind)
            epoch = plot_ind[ind]
            print("Epoch Number: {}".format(epoch))
            #print(w)
            plt.imshow(w)
            # display.clear_output(wait=True)
            plt.xlabel('epoch='+str(epoch))
            plt.ylabel('sigma='+str(sigma_0))
            plt.show()


            #display.display(plt.gcf())


        epoch += 1

    plt.imshow(w)