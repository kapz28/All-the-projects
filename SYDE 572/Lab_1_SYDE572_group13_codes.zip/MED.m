% MED
%
% INPUTS:
% x1 - 1xN vector - range of x1 component
% x2 - 1xM vector - range of x2 component
% mu - Lx2 vector - means of L classes
%
% OUTPUT:
% Y - NxM matrix - classification result for the range of x1, x2
function Y = MED(x1, x2, mu)

Y = zeros( length(x1), length(x2) );
for i=1:length(x1)
    for j=1:length(x2)
        v = [x1(i) x2(j)];
        sq = (v-mu).^2;
        dist = sqrt(sq(:,1) + sq(:,2));
        [~, ind] = min(dist);
        Y(i,j) = ind;
    end
end