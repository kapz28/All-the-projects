% SYDE 572 Lab 1
% Section 4: Error Analysis
% Date: 26 Feb 2021
% Names: 
%   Jae Wan Cho (jw3cho)
%   Kapilan Satkunanathan (k3satkun)
%   Shraddha Shah (s222shah)
%   Anna Shan (yq2shan)
clc
clear % clear all variables from memory
close all % close all open figures
load('lab1_data') % load data from previous section

% organize class data to generate confusion matrix
classdataone={data_A};
classdataone{2}=data_B;
classdatatwo={data_C};
classdatatwo{2}=data_D;
classdatatwo{3}=data_E;

%% Confusion Matrix Generation
% Generate confusion matrix for MED
confmat_med_ab = generateconfusionmatrix(x1_ab, x2_ab, classdataone, y_med_ab)
confmat_med_cde= generateconfusionmatrix(x1_cde, x2_cde, classdatatwo, y_med_cde)

% Generate confusion matrix for MICD
confmat_micd_ab = generateconfusionmatrix(x1_ab, x2_ab, classdataone, y_micd_ab)
confmat_micd_cde= generateconfusionmatrix(x1_cde, x2_cde, classdatatwo, y_micd_cde)

% Generate confusion matrix for MAP
confmat_map_ab = generateconfusionmatrix(x1_ab, x2_ab, classdataone, y_map_ab)
confmat_map_cde= generateconfusionmatrix(x1_cde, x2_cde, classdatatwo, y_map_cde)

% Generate confusion matrix for NN
confmat_nn_ab = generateconfusionmatrix(x1_ab, x2_ab, classdataone, y_nn_ab)
confmat_nn_cde= generateconfusionmatrix(x1_cde, x2_cde, classdatatwo, y_nn_cde)

% Generate confusion matrix for kNN
confmat_knn_ab = generateconfusionmatrix(x1_ab, x2_ab, classdataone, y_knn_ab)
confmat_knn_cde= generateconfusionmatrix(x1_cde, x2_cde, classdatatwo, y_knn_cde)

%% Generate Experimental Error 
experr_ab = calcexperrrate(x1_ab,x2_ab,classdataone,[mu_A;mu_B],[sigma_A;sigma_B],[N_A,N_B])
experr_cde= calcexperrrate(x1_cde,x2_cde,classdatatwo,[mu_C;mu_D;mu_E],[sigma_C;sigma_D;sigma_E],[N_C,N_D,N_E])

%% Save data for next sections
save('lab1_data')