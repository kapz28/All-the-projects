% Calculate Experimental Error Rate
%
% INPUTS:
% x1 - 1xN vector - range of x1 component
% x2 - 1xM vector - range of x2 component
% data - Lx2xn vector - data set containing each classes random data 
% mu - Lx2 vector - means of L classes
% sigma - 2Lx2 vector - covariance matrices of L classes
% N - Lx1 vector - sample size of L classes
%
% OUTPUT:
% Y - NxM matrix - classification result for the range of x1, x2
function Y = calcexperrrate(x1, x2, data, mu, sigma, N)

Y = 0;
indiviprob = zeros(length(mu),1);
for h=1:length(mu)
    indiviprob(h) = N(h) / sum(N);
end
store = zeros( length(x1), length(x2) );
for i=1:length(x1)
    for j=1:length(x2)
        v = [x1(i) x2(j)];
        prob = zeros(length(mu),1);
        for k=1:length(mu)
            S = sigma(2*k-1:2*k,:);
            prob(k) = (1 / (sqrt(2*pi)*det(S))) * ...
                exp(-0.5*(v-mu(k,:))*inv(S)*(v-mu(k,:))');
        end
         store(i,j)= sqrt(prod(prob));
        
    end
end

x1 = round(x1,1);
x2 = round(x2,1);
lowboundx= x1(1);
upboundx = x1(length(x1));
lowboundy= x2(1);
upboundy = x2(length(x2));

for i = 1:length(data)
    N = data{i};
    for j = 1:length(N)
        M = N(j,:);
        point = round(M, 1);
        if point(1) < lowboundx
            point(1) = lowboundx;
        end
        if point(1) > upboundx
            point(1) = upboundx;
        end
        if point(2) < lowboundy
            point(2) = lowboundy;
        end        
        if point(2) > upboundy
            point(2) = upboundy;
        end
        xind = find(x1 == point(1));
        yind = find(x2 == point(2));
        val = store(xind(1),yind(1));
        Y = Y + val;
    end
end
Y = sqrt(prod(indiviprob))*Y;