% SYDE 572 Lab 1
% Section 2: Generating Clusters
% Date: 26 Feb 2021
% Names: 
%   Jae Wan Cho (jw3cho)
%   Kapilan Satkunanathan (k3satkun)
%   Shraddha Shah (s222shah)
%   Anna Shan (yq2shan)

clear % clear all variables from memory
close all % close all open figures

%% Initial setup

% Define mean, variance, sample size for all classes
N_A = 200;
mu_A = [5 10];
sigma_A = [8 0; 0 4];
N_B = 200;
mu_B = [10 15];
sigma_B = [8 0; 0 4];
N_C = 100;
mu_C = [5 10];
sigma_C = [8 4; 4 40];
N_D = 200;
mu_D = [15 10];
sigma_D = [8 0; 0 8];
N_E = 150;
mu_E = [10 5];
sigma_E = [10 -5; -5 20];

% Generate data points for all classes
data_A = repmat(mu_A, N_A, 1) + randn(N_A, 2)*chol(sigma_A);
data_B = repmat(mu_B, N_B, 1) + randn(N_B, 2)*chol(sigma_B);
data_C = repmat(mu_C, N_C, 1) + randn(N_C, 2)*chol(sigma_C);
data_D = repmat(mu_D, N_D, 1) + randn(N_D, 2)*chol(sigma_D);
data_E = repmat(mu_E, N_E, 1) + randn(N_E, 2)*chol(sigma_E);

% Get eigenvalues of covariance matrix for all classes
egval_A = eig(sigma_A);
egval_B = eig(sigma_B);
egval_C = eig(sigma_C);
egval_D = eig(sigma_D);
egval_E = eig(sigma_E);

%% Plot classes A & B

pt_size = 15;
figure
scatter(data_A(:,1), data_A(:,2), pt_size, 'r', 'filled');
hold on
scatter(data_B(:,1), data_B(:,2), pt_size, 'b', 'filled');

% Unit standard deviation contour for class A
t = linspace(0,2*pi,1000);
x = sqrt(egval_A(2)) * sin(t) + mu_A(1);
y = sqrt(egval_A(1)) * cos(t) + mu_A(2);
plot(x,y,'r','HandleVisibility','off')

% Unit standard deviation contour for class B
x = sqrt(egval_B(2)) * sin(t) + mu_B(1);
y = sqrt(egval_B(1)) * cos(t) + mu_B(2);
plot(x,y,'b','HandleVisibility','off')

% Plot labels + formatting
legend('Class A','Class B')
xlabel('x_1');
ylabel('x_2');
title('Data and Unit Standard Deviation Contour Plot (Classes A & B)');
axis equal
xlim([-3 17])
ylim([2 20])
savefig('contourAB.fig')

%% Plot classes C, D, E

figure
scatter(data_C(:,1), data_C(:,2), pt_size, 'r', 'filled');
hold on
scatter(data_D(:,1), data_D(:,2), pt_size, 'b', 'filled');
scatter(data_E(:,1), data_E(:,2), pt_size, 'g', 'filled');

% Unit standard deviation contour for class C
angle = atan(sqrt(sigma_C(4)/sigma_C(1))); % positive angle because b > 0
a = sqrt(egval_C(2));
b = sqrt(egval_C(1));
x = a*cos(t)*cos(angle) - b*sin(t)*sin(angle) + mu_C(1); 
y = b*sin(t)*cos(angle) + a*cos(t)*sin(angle) + mu_C(2);
plot(x,y,'r','HandleVisibility','off')

% Unit standard deviation contour for class D
x = sqrt(egval_D(2)) * sin(t) + mu_D(1);
y = sqrt(egval_D(1)) * cos(t) + mu_D(2);
plot(x,y,'b','HandleVisibility','off')

% Unit standard deviation contour for class E
angle = -atan(sqrt(sigma_E(4)/sigma_E(1))); % negative angle because b < 0
a = sqrt(egval_E(2));
b = sqrt(egval_E(1));
x = a*cos(t)*cos(angle) - b*sin(t)*sin(angle) + mu_E(1); 
y = b*sin(t)*cos(angle) + a*cos(t)*sin(angle) + mu_E(2);
plot(x,y,'g','HandleVisibility','off')

% Plot labels + formatting
legend('Class C','Class D','Class E')
xlabel('x_1');
ylabel('x_2');
title('Data and Unit Standard Deviation Contour Plot (Classes C, D, E)');
axis equal
xlim([-5 25])
ylim([-8 24])
savefig('contourCDE.fig')

%% Save data for next sections
save('lab1_data')