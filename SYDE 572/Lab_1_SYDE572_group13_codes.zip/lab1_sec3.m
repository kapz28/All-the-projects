% SYDE 572 Lab 1
% Section 3: Classifiers
% Date: 26 Feb 2021
% Names: 
%   Jae Wan Cho (jw3cho)
%   Kapilan Satkunanathan (k3satkun)
%   Shraddha Shah (s222shah)
%   Anna Shan (yq2shan)

clear % clear all variables from memory
close all % close all open figures
load('lab1_data') % load data from previous section

%% Initial setup + calculations

% Set step size and ranges for x1, x2
dx = 0.1;
x1_ab = [-3:dx:17];
x2_ab = [2:dx:20];
x1_cde = [-5:dx:25];
x2_cde = [-8:dx:24];

% Generate classification grid using MED
y_med_ab = MED(x1_ab,x2_ab,[mu_A;mu_B]);
y_med_cde = MED(x1_cde,x2_cde,[mu_C;mu_D;mu_E]);

% Generate classification grid using MICD
y_micd_ab = MICD(x1_ab,x2_ab,[mu_A;mu_B],[sigma_A;sigma_B]);
y_micd_cde = MICD(x1_cde,x2_cde, ...
    [mu_C;mu_D;mu_E],[sigma_C;sigma_D;sigma_E]);

% Generate classification grid using MAP
y_map_ab = MAP(x1_ab,x2_ab,[mu_A;mu_B],[sigma_A;sigma_B],[N_A,N_B]);
y_map_cde = MAP(x1_cde,x2_cde, ...
    [mu_C;mu_D;mu_E],[sigma_C;sigma_D;sigma_E],[N_C,N_D,N_E]);

%% Generate classification grid using NN
resp_ab = [ones(N_A,1);repmat(2,N_B,1)];
resp_cde = [repmat(1,N_C,1);repmat(2,N_D,1);repmat(3,N_E,1)];
y_nn_ab = kNN(x1_ab,x2_ab,[data_A;data_B],resp_ab,1);
y_nn_cde = kNN(x1_cde,x2_cde,[data_C;data_D;data_E],resp_cde,1);

%% Generate classification grid using kNN (n = 5)
y_knn_ab = kNN(x1_ab,x2_ab,[data_A;data_B],resp_ab,5);
y_knn_cde = kNN(x1_cde,x2_cde,[data_C;data_D;data_E],resp_cde,5);

%% Plots for classes A & B

% MED, MICD, MAP plot for classes A & B
openfig('contourAB.fig');
contour(x1_ab,x2_ab,y_med_ab','m');
hold on
contour(x1_ab,x2_ab,y_micd_ab','c');
contour(x1_ab,x2_ab,y_map_ab','k--');
legend('Class A','Class B', ...
    'MED Boundary','MICD Boundary','MAP Boundary');
title('Classification Boundaries Using MED, MICD, MAP (Classes A & B)');
axis equal
xlim([-3 17])
ylim([2 20])

% NN, kNN plot for classes A & B
openfig('contourAB.fig');
contour(x1_ab,x2_ab,y_nn_ab','m');
hold on
contour(x1_ab,x2_ab,y_knn_ab','c');
legend('Class A','Class B','NN Boundary','5NN Boundary');
title('Classification Boundaries Using NN & 5NN (Classes A & B)');
axis equal
xlim([-3 17])
ylim([2 20])

%% Plots for classes C, D, E

% MED, MICD, MAP plot for classes C, D, E
openfig('contourCDE.fig');
contour(x1_cde,x2_cde,y_med_cde','m');
hold on
contour(x1_cde,x2_cde,y_micd_cde','c');
contour(x1_cde,x2_cde,y_map_cde','k');
legend('Class C','Class D','Class E', ...
    'MED Boundary','MICD Boundary','MAP Boundary');
xlabel('x_{1}');
ylabel('x_{2}');
title('Classification Boundaries Using MED, MICD, MAP (Classes C, D, E)');
axis equal
xlim([-5 25])
ylim([-8 24])

% NN, kNN plot for classes C, D, E
openfig('contourCDE.fig');
contour(x1_cde,x2_cde,y_nn_cde','m');
hold on
contour(x1_cde,x2_cde,y_knn_cde','c');
legend('Class C','Class D','Class E','NN Boundary','5NN Boundary');
xlabel('x_{1}');
ylabel('x_{2}');
title('Classification Boundaries Using NN & 5NN (Classes C, D, E)');
axis equal
xlim([-5 25])
ylim([-8 24])

%% Save data for next sections
save('lab1_data')