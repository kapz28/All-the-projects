% MAP
%
% INPUTS:
% x1 - 1xN vector - range of x1 component
% x2 - 1xM vector - range of x2 component
% mu - Lx2 vector - means of L classes
% sigma - 2Lx2 vector - covariance matrices of L classes
% N - Lx1 vector - sample size of L classes
%
% OUTPUT:
% Y - NxM matrix - classification result for the range of x1, x2
function Y = MAP(x1, x2, mu, sigma, N)

Y = zeros( length(x1), length(x2) );
for i=1:length(x1)
    for j=1:length(x2)
        v = [x1(i) x2(j)];
        prob = zeros(length(mu),1);
        for k=1:length(mu)
            S = sigma(2*k-1:2*k,:);
            prob(k) = sum(N) / N(k) / (sqrt(2*pi)*det(S)) * ...
                exp(-0.5*(v-mu(k,:))*inv(S)*(v-mu(k,:))');
        end
        [~, ind] = max(prob);
        Y(i,j) = ind;
    end
end