% Generate Confusion Matrix
%
% INPUTS:
% x1 - 1xN vector - range of x1 component
% x2 - 1xM vector - range of x2 component
% data - Lx2xn vector - data set containing each classes random data 
% classgrid - NxM vector - classification grid
%
% OUTPUT:
% Y - 2x2 matrix - [[TP FP];[FN TN]];
function Y = generateconfusionmatrix(x1, x2, data, classgrid)

Y = zeros(length(data));
x1 = round(x1,1);
x2 = round(x2,1);
lowboundx= x1(1);
upboundx = x1(length(x1));
lowboundy= x2(1);
upboundy = x2(length(x2));

for i = 1:length(data)
    N = data{i};
    for j = 1:length(N)
        M = N(j,:);
        point = round(M, 1);
        if point(1) < lowboundx
            point(1) = lowboundx;
        end
        if point(1) > upboundx
            point(1) = upboundx;
        end
        if point(2) < lowboundy
            point(2) = lowboundy;
        end        
        if point(2) > upboundy
            point(2) = upboundy;
        end
        xind = find(x1 == point(1));
        yind = find(x2 == point(2));
        resp = classgrid(xind(1),yind(1));
        if resp == i
            Y(i,i) = Y(i,i) + 1;
        else
            Y(resp,i) = Y(resp,i) + 1;
        end
    end
end