% kNN
%
% INPUTS:
% x1 - 1xN vector - range of x1 component
% x2 - 1xM vector - range of x2 component
% data - Lx2 vector - sample points 
% res - Lx1 class for each sample point
% k - number of cluster samples for kNN
%
% OUTPUT:
% Y - NxM matrix - classification result for the range of x1, x2
function Y = kNN(x1, x2, data, res, k)

mdl = fitcknn(data, res, 'NumNeighbors', k);
Y = zeros( length(x1), length(x2) );
for i=1:length(x1)
    for j=1:length(x2)
        v = [x1(i) x2(j)];
        Y(i,j) = predict(mdl,v);
    end
end